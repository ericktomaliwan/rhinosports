<div class="page-header">
  @if ( !is_page() )
    <h1>{!! $title !!}</h1>
  @endif
</div>
